console.log("Script Running....");
document.querySelector('.cross').style.display='none';
document.querySelector('.humBurger').addEventListener("click",()=>{
	document.querySelector('.sidebar').classList.toggle('sidebarGo');
	if(document.querySelector('.sidebar').classList.contains('sidebarGo'))
	{
		document.querySelector('.hamp').style.display='inline';
		document.querySelector('.cross').style.display='none';
	}
	else
	{
		document.querySelector('.hamp').style.display='none';
		setTimeout(()=>
		{
			document.querySelector('.cross').style.display='inline';
		},300);
		
	}
})

/* Js for when click on button it will get my cv */
// Get the download CV button element
var downloadCVButton = document.getElementById("download-cv-button");

// Add a click event listener to the button
downloadCVButton.addEventListener("click", function() {
  // Replace the URL with the path to your CV file
  var cvURL = "cv/Dani both.pdf";
  
  // Open the CV in a new tab/window
  window.open(cvURL, "_blank");
});
